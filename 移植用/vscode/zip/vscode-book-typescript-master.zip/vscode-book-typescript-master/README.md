# Visual Studio Code 実践ガイド 2.10章 TypeScriptでの開発 サンプルコード

## LICENSE

- MIT License
- Visual Studio Code 実践ガイドの購入者、組織は、無制限の改変、コピー、配布を許可
